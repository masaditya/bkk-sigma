<?php echo e($slot); ?>

<?php /**PATH /Users/adityaeka/Workspace/laravel-react/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>