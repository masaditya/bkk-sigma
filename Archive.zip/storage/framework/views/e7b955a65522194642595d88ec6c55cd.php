<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/adityaeka/Workspace/laravel-react/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>